// Define the contact details
const email = "tapanmahapatra404@gmail.com";
const phoneNumber = "9040839305";
const whatsappNumber = "9040839305";

function redirectMail() {
    window.location.href = `mailto:${email}`;
}

function redirectCall() {
    window.location.href = `tel:${phoneNumber}`;
}

function redirectWhatsApp() {
    window.location.href = `https://wa.me/${whatsappNumber}`;
}